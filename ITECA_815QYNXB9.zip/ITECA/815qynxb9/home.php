<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>815qynxb9</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
 
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<div class="home-bg">
<section class="home">
  
   <div class="swiper home-slider">
   
   <div class="swiper-wrapper">
      
      <div class="swiper-slide slide">
        
         <div class="content">
           
            <h3 style="color: black;">YES! WE DO HOME REPAIRS AND PAINTING!</h3>
            <a href="contact.php" class="btn" style="background-color: black;" >Book Now</a>
         </div>
          <div class="image">
            <img src="images/painter.png" alt="">
         </div>
        
      </div>

      <div class="swiper-slide slide">
          
         <div class="image">
            <img src="images/equip.png" alt="">
         </div>

         <div class="content">
            <h3 style="color: black;">Home repair and paint items</h3>
            <a href="shop.php" class="btn" style="background-color: black;">shop now</a>
         </div>
      </div>

   </div>

      <div class="swiper-pagination"></div>

   </div>

    <div class ="content">
        <h1 class="heading" style="color: black;"> WHAT WE DO AT HAYDN HOME SERVICES</h1>
    </div>
    
       //815qynxb9
       
    <div class="heading">
        <img  src="images/repair2.png" alt="" />
        <a href="about.php" class="btn" style="background-color: black;">learn more</a>
    </div>
        
  
  

    

</section>

</div>


<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".home-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
    },
});

</script>

</body>
</html>