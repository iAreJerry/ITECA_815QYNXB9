<?php

$db_name = 'mysql:host=localhost;dbname=815qynxb9_db';
$user_name = 'root';
$user_password = '';
//815qynxb9
$conn = new PDO($db_name, $user_name, $user_password);

?>