
<header class="header" style="background : black;">

   <section class="flex">

      <a href="home.php" class="logo" style=" color: white;" >Haydn Home Services</a>

      <nav class="navbar">
         <a href="about.php" style=" color: white;">about</a>
         <a href="shop.php" style=" color: white;" >shop</a>
         <a href="contact.php" style=" color: white;" >contact</a>
      </nav>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars" style=" color: white;" ></div>
         <div id="user-btn" class="fas fa-user"style=" color: white;" ></div>
      </div>

      <div class="profile">
         <?php          
            $select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
            $select_profile->execute([$user_id]);
            if($select_profile->rowCount() > 0){
            $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <p><?= $fetch_profile["name"]; ?></p>
         
         <a style="background-color: black;" href="components/user_logout.php" class="btn" onclick="return confirm('logout from the website?');">logout</a> 
         <?php
            }else{
         ?>
         <p>Log In or Register</p>
         <div class="flex-btn">
            <a style="background-color: black;" href="user_register.php" class="btn">Register</a>
            <a style="background-color: black;" href="user_login.php" class="btn">Login</a>
         </div>
         <?php
            }
         ?>      
         
         
      </div>

   </section>

</header>