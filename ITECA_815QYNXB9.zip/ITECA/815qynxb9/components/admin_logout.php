<?php

include 'connect.php';
//815qynxb9
session_start();
session_unset();
session_destroy();

header('location:../admin/admin_login.php');

?>