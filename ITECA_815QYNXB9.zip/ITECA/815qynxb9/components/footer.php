<footer class="footer" >

   <section class="grid" >
       //815qynxb9
        <div class="box">
         <h3>follow us</h3>
         <a href="#"></i>Facebook</a>
         <a href="#"></i>Twitter</a>
         <a href="#"></i>Instagram</a>
         <a href="#"></i>TikTok</a>
      </div>

      <div class="box">
         <h3>CONTACT US</h3>
         <a href="tel:0612556050"> 0612556050</a>
         <a href="mailto:info@hhs.co.za"> info@hss.co.za </a>
      </div>


   </section>

   <div style=" background: black; color: white;"  class="credit">&copy;  ITECA, 815QYNXB9  <?= date('Y'); ?> </div >

</footer>