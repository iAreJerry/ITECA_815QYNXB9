<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>815qynxb9</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="about">

   <div class="row">

      <div class="images">
         <img src="images/phone.png" alt="">
      </div>

      <div class="content">
         <h3>WHO ARE WE?</h3>
         <p> Here at Haydn Home services our goal is to make your home look like home again. Removing those old cracks and broken stones from your house making it look modern. IF you are interested click the button below to contact us for more details! </p>
         <a style="background-color: black;" href="contact.php" class="btn">CONTACT US NOW</a>
      </div>

   </div>

</section>


<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>



</body>
</html>